nama=input("Masukkan nama : ")
umur=input("Masukkan umur : ")
tinggi=input("Masukkan tinggi badan : ")

print ("Nama saya {}, umur  {} tahun dan tinggi saya {}".format (nama,umur,tinggi))
