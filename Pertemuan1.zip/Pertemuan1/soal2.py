jari = float(input("masukkan jari-jari = "))
phi = float(22.0/7)
luas= phi*jari*jari
print ("Luas lingkaran dengan jari-jari {} cm adalah {:.2f} cm""\u00b2".format(jari,luas))
